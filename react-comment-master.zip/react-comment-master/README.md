# react-comment

**npm install**  
**cd server**  
**node server.js**  
**`localhost:3000`**
